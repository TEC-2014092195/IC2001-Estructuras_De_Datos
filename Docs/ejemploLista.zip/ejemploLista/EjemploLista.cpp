// #include "alist.h"
#include "llist.h"
using namespace std;

int main () {
  LList<string> lista1;
//AList<string> lista1;
  
  lista1.insert("Juan");
  lista1.insert("Pedro");
  lista1.insert("Pablo");
  
  for (int i=0;i<lista1.length();i++) {
    string nombre = lista1.getValue();
    cout << nombre  << endl;
    lista1.next();
  }
  return EXIT_SUCCESS;
}